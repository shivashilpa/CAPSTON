package com.infy.ekart.dto;

public enum OrderStatus {
	 PLACED, CONFIRMED, CANCELLED
}
