package com.infy.ekart.service.test;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class CustomerServiceTest {
	//Write testcases here
	
}
